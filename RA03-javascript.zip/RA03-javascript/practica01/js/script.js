// Seleccionar elements
const titol = document.getElementById('titol');
const paragraf = document.querySelector('.paragraf');
const botoCanviarText = document.getElementById('canviarText');
const botoAfegir = document.getElementById('afegirElement');
const botoEliminar = document.getElementById('eliminarElement');
const llista = document.getElementById('llista');

// Modificar contingut i estils
titol.textContent = 'Manipulació del DOM!';
titol.style.color = 'green';

paragraf.textContent = 'Text modificat en negreta.';
paragraf.style.fontWeight = 'bold';

// Esdeveniments
botoCanviarText.addEventListener('click', function () {
    titol.textContent = 'Has canviat el text!';
    titol.style.color = 'red';
});

// Afegir i eliminar elements
botoAfegir.addEventListener('click', function () {
    const nouElement = document.createElement('li');
    nouElement.textContent = 'Nou element afegit!';
    llista.appendChild(nouElement);
});

botoEliminar.addEventListener('click', function () {
    llista.lastChild?.remove();
});

// Mouseover per als botons per quan passi el ratolí per sobre
botoCanviarText.addEventListener('mouseover', function () {
    botoCanviarText.style.backgroundColor = 'darkblue';
});

botoAfegir.addEventListener('mouseover', function () {
    botoAfegir.style.backgroundColor = 'darkgreen';
});

botoEliminar.addEventListener('mouseover', function () {
    botoEliminar.style.backgroundColor = 'darkred';
});

// Mouseout per quan el ratolí surt del botó i es desactivin els colors
botoCanviarText.addEventListener('mouseout', function () {
    botoCanviarText.style.backgroundColor = '';
});

botoAfegir.addEventListener('mouseout', function () {
    botoAfegir.style.backgroundColor = '';
});

botoEliminar.addEventListener('mouseout', function () {
    botoEliminar.style.backgroundColor = '';
});
